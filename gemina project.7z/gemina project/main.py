from fastapi import FastAPI, HTTPException, Header, Form
from pydantic import BaseModel
from typing import Optional
import json, os, uuid, requests
from dotenv import load_dotenv
from datetime import datetime

# 🔹 .env file se environment variables load karne ke liye
load_dotenv()

# 🔹 FastAPI app create ho rahi hai
app = FastAPI(title="FastAPI + Login + Token + Gemini Prompt API")

# 🔹 JSON files ke naam (user, course aur access log store karne ke liye)
USERS_FILE = "users.json"
COURSES_FILE = "courses.json"
ACCESS_FILE = "user_access_apikey.json"

# 🔹 Gemini API key environment se load kar rahe hain
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# ==============================
# 💾 Helper functions
# ==============================

# File load karne ke liye function
def load_json(filename):
    if os.path.exists(filename):
        with open(filename, "r") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return {}
    return {}

# File save karne ke liye function
def save_json(filename, data):
    with open(filename, "w") as f:
        json.dump(data, f, indent=4)

# Har Gemini access record store karne ke liye
def append_access_record(record: dict):
    data = load_json(ACCESS_FILE)
    new_id = str(max(map(int, data.keys())) + 1 if data else 1)
    data[new_id] = record
    save_json(ACCESS_FILE, data)

# ==============================
# 🔐 Authentication System
# ==============================

# 🔸 User register karne ka route
@app.post("/register")
def register(username: str = Form(...), password: str = Form(...)):
    users = load_json(USERS_FILE)
    if username in users:
        raise HTTPException(status_code=400, detail="Username already exists")
    users[username] = {"password": password, "token": ""}
    save_json(USERS_FILE, users)
    return {"message": "User registered successfully"}

# 🔸 User login aur token generate karne ka route
@app.post("/login")
def login(username: str = Form(...), password: str = Form(...)):
    users = load_json(USERS_FILE)
    if username not in users or users[username]["password"] != password:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    token = str(uuid.uuid4())
    users[username]["token"] = token
    save_json(USERS_FILE, users)
    return {"message": "Login successful", "token": token}

# 🔸 Token verify karne ka helper function
def verify_token(token: Optional[str]):
    if not token:
        raise HTTPException(status_code=401, detail="Token missing")
    users = load_json(USERS_FILE)
    for username, info in users.items():
        if info.get("token") == token:
            return username
    raise HTTPException(status_code=401, detail="Invalid or expired token")

# ==============================
# 🤖 Gemini API Route
# ==============================

@app.post("/ask_gemini")
def ask_gemini(
    username: str = Form(...),
    password: str = Form(...),
    prompt: str = Form(...),
    token: Optional[str] = Header(None)
):
    # Agar key missing ho to error
    if not GEMINI_API_KEY:
        raise HTTPException(status_code=500, detail="Gemini API key not configured")

    # User verify karna
    users = load_json(USERS_FILE)
    if username not in users or users[username]["password"] != password:
        raise HTTPException(status_code=401, detail="Invalid username or password")

    # Token verify karna
    if users[username].get("token") != token:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

    # Gemini API call ke liye URL aur headers
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"
    headers = {
        "Content-Type": "application/json",
        "x-goog-api-key": GEMINI_API_KEY
    }
    payload = {
        "contents": [
            {
                "parts": [
                    {"text": prompt}
                ]
            }
        ]
    }

    # Gemini API se response lena
    try:
        resp = requests.post(url, headers=headers, json=payload)
        resp.raise_for_status()
        result = resp.json()
        candidates = result.get("candidates")
        if not candidates or not isinstance(candidates, list):
            raise Exception("No candidates in Gemini response")

        content = candidates[0].get("content")
        if not content:
            raise Exception("No content in candidate")

        parts = content.get("parts")
        if not parts or not isinstance(parts, list):
            raise Exception("No parts in content")

        # Response text combine karna
        text_out = "".join([p.get("text", "") for p in parts])
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gemini API error: {e}")

    # Record save karna
    record = {
        "username": username,
        "prompt": prompt,
        "response": text_out,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }
    append_access_record(record)

    return {
        "username": username,
        "prompt": prompt,
        "response": text_out
    }

# ==============================
# 📚 Courses CRUD System
# ==============================

class Course(BaseModel):
    title: str
    instructor: str
    duration: int  # in weeks or hours etc.

# Saare courses list karne ke liye
@app.get("/courses")
def get_courses(token: Optional[str] = Header(None)):
    verify_token(token)
    data = load_json(COURSES_FILE)
    return data

# Naya course add karne ke liye
@app.post("/courses")
def add_course(course: Course, token: Optional[str] = Header(None)):
    verify_token(token)
    data = load_json(COURSES_FILE)
    new_id = str(max(map(int, data.keys())) + 1 if data else 1)
    data[new_id] = course.dict()
    save_json(COURSES_FILE, data)
    return {"message": "Course added successfully", "id": new_id}

# Course update karne ke liye
@app.put("/courses/{course_id}")
def update_course(course_id: str, course: Course, token: Optional[str] = Header(None)):
    verify_token(token)
    data = load_json(COURSES_FILE)
    if course_id not in data:
        raise HTTPException(status_code=404, detail="Course not found")
    data[course_id] = course.dict()
    save_json(COURSES_FILE, data)
    return {"message": "Course updated", "course": data[course_id]}

# Course delete karne ke liye
@app.delete("/courses/{course_id}")
def delete_course(course_id: str, token: Optional[str] = Header(None)):
    verify_token(token)
    data = load_json(COURSES_FILE)
    if course_id not in data:
        raise HTTPException(status_code=404, detail="Course not found")
    del data[course_id]
    save_json(COURSES_FILE, data)
    return {"message": "Course deleted successfully"}

# Root endpoint check karne ke liye
@app.get("/")
def read_root():
    return {"message": "Welcome to the FastAPI + Gemini Prompt System with Courses"}
